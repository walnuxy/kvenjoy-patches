import com.kenjoy.kenjoycnc.KenjoyDraw;
import com.kenjoy.kenjoycnc.data.*;
import com.kenjoy.kenjoycnc.note.*;
import com.kenjoy.kenjoycnc.processTabs.NoteTab;
import com.kenjoy.kenjoycnc.processTabs.g;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.lang.reflect.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.*;

/** Integration assertions against the real application classes and bundled Java8. No devices. */
public final class NoteChecks {
    static NoteTab tab;static g canvas;static Path evidence;
    static final List<String> results=new ArrayList<String>();
    static void edt(Runnable r)throws Exception {if(SwingUtilities.isEventDispatchThread())r.run();else SwingUtilities.invokeAndWait(r);}
    static JOptionPane saveQuestion(Container container){if(container instanceof JOptionPane)return (JOptionPane)container;for(Component child:container.getComponents())if(child instanceof Container){JOptionPane pane=saveQuestion((Container)child);if(pane!=null)return pane;}return null;}
    static Object field(Object target,String name)throws Exception{Field f=target.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(target);}
    static void field(Object target,String name,Object value)throws Exception{Field f=target.getClass().getDeclaredField(name);f.setAccessible(true);f.set(target,value);}
    static Object exporter(String prefix,int copies,boolean images)throws Exception{final Object[] result={null};edt(()->{try{Object x=Class.forName("com.kenjoy.kenjoycnc.m").newInstance();((JRadioButton)field(x,images?"c":"b")).setSelected(true);((JRadioButton)field(x,"e")).setSelected(true);field(x,"p",0);field(x,"q",tab.getPageNum());field(x,"s",copies);field(x,"y",true);java.io.File folder=evidence.resolve("batch").toFile();folder.mkdirs();field(x,"t",folder);field(x,"u",prefix);result[0]=x;}catch(Exception e){throw new RuntimeException(e);}});return result[0];}
    static void check(String name,boolean pass)throws Exception {results.add((pass?"PASS":"FAIL")+"\t"+name);Files.write(evidence.resolve("checks.tsv"),results,java.nio.charset.StandardCharsets.UTF_8);if(!pass)throw new AssertionError(name);System.out.println("NOTE_CHECK PASS "+name);}
    static void waitDone()throws Exception {long end=System.currentTimeMillis()+45000;while(true){final boolean[] busy={false};edt(()->busy[0]=tab.isBusy());if(!busy[0])break;if(System.currentTimeMillis()>end)throw new AssertionError("layout timeout");Thread.sleep(30);}edt(()->{});}
    static String geometry(NoteLayout l){StringBuilder out=new StringBuilder();for(NoteLayout.Page p:l.pages)for(NoteLayout.Glyph g:p.glyphs){out.append(g.id).append(Arrays.toString(g.path.a())).append(Arrays.toString(g.path.b()));}return out.toString();}
    static boolean pathsNear(List<com.kenjoy.kenjoycnc.g.e> a,List<com.kenjoy.kenjoycnc.g.e> b,float tolerance){if(a.size()!=b.size())return false;for(int i=0;i<a.size();i++){if(!Arrays.equals(a.get(i).b(),b.get(i).b()))return false;float[] x=a.get(i).a(),y=b.get(i).a();if(x.length!=y.length)return false;for(int j=0;j<x.length;j++)if(Math.abs(x[j]-y[j])>tolerance)return false;}return true;}
    static boolean affinePathsNear(List<com.kenjoy.kenjoycnc.g.e> source,List<com.kenjoy.kenjoycnc.g.e> machine,AffineTransform transform,float tolerance){if(source.size()!=machine.size())return false;for(int i=0;i<source.size();i++){byte[] flags=source.get(i).b();if(!Arrays.equals(flags,machine.get(i).b()))return false;float[] xy=source.get(i).a(),actual=machine.get(i).a();if(xy.length!=actual.length)return false;double[] expected=new double[xy.length];for(int j=0;j<xy.length;j++)expected[j]=xy[j];transform.transform(expected,0,expected,0,flags.length);for(int j=0;j<actual.length;j++)if(!Double.isFinite(expected[j])||Math.abs(expected[j]-actual[j])>tolerance)return false;}return true;}
    static AffineTransform screen()throws Exception{Class<?> base=canvas.getClass().getSuperclass();Field l=base.getDeclaredField("l"),m=base.getDeclaredField("m");l.setAccessible(true);m.setAccessible(true);AffineTransform out=new AffineTransform((AffineTransform)m.get(canvas));out.concatenate((AffineTransform)l.get(canvas));return out;}
    static Point screen(double x,double y)throws Exception{return canvas.previewPoint(tab.getCurrentPageIndex(),(float)x,(float)y);}
    static void clickGlyph(NoteLayout.Glyph glyph,int modifiers)throws Exception{Point p=screen(glyph.cell.getCenterX(),glyph.cell.getCenterY());canvas.dispatchEvent(new MouseEvent(canvas,MouseEvent.MOUSE_PRESSED,System.currentTimeMillis(),modifiers,p.x,p.y,1,false,MouseEvent.BUTTON1));canvas.dispatchEvent(new MouseEvent(canvas,MouseEvent.MOUSE_RELEASED,System.currentTimeMillis(),modifiers,p.x,p.y,1,false,MouseEvent.BUTTON1));}
    static NoteLayout.Glyph glyph(long id){for(NoteLayout.Page p:tab.noteLayout().pages)for(NoteLayout.Glyph g:p.glyphs)if(g.id==id)return g;throw new AssertionError("glyph not found");}
    static NoteDocument sample(NoteFonts fonts)throws Exception {
        NoteDocument d=new NoteDocument();d.page=new PageInfo("检查",160,100,10,10,10,10,5,75,true);d.page.space=0.8f;d.format.autoGp=false;d.format.charset="UTF-8";
        for(NoteFonts.Entry e:fonts.entries())if(e.file.getName().equals("晓李手写_kvenjoy_aren.gfont"))d.pool.add(fonts.ref(e));
        if(d.pool.isEmpty())for(NoteFonts.Entry e:fonts.entries())if(e.folder.startsWith("中文")){d.pool.add(fonts.ref(e));break;}
        d.replace(0,0,"春风又绿江南岸，明月何时照我还。春风又春。\n这是第二行，选择整行也可以修改字体。\n第三段用于检查换行与分页，汉字按具体位置保存。\n第四段继续检查文章保存与导出。\n第五段用于跨页选择。\n第六段仍然保持原有字体。");return d;
    }
    public static void run()throws Exception {
        evidence=Paths.get(System.getProperty("note.evidence"));Files.createDirectories(evidence);
        check("patched batch exporter verifies",Class.forName("com.kenjoy.kenjoycnc.m").getDeclaredMethods().length>0);
        long deadline=System.currentTimeMillis()+20000;
        while(KenjoyDraw.a()==null&&System.currentTimeMillis()<deadline)Thread.sleep(50);
        edt(()->{try{JComboBox modes=(JComboBox)field(KenjoyDraw.a(),"e");for(int i=0;i<modes.getItemCount();i++)if(modes.getItemAt(i) instanceof NoteTab){modes.setSelectedIndex(i);tab=(NoteTab)modes.getItemAt(i);break;}canvas=(g)field(tab,"notePanel");}catch(Exception e){throw new RuntimeException(e);}});
        Path pageFile=com.kenjoy.kenjoycnc.L.b().toPath().resolve("page_settings.json");byte[] savedPages=Files.exists(pageFile)?Files.readAllBytes(pageFile):null;
        FontsDialogData defaults=(FontsDialogData)Storage.getStore(FontsDialogData.class);String[] savedFonts=defaults.fontsName;int[] savedChances=defaults.chance;PageInfo[] startupPage={null};
        try{
            PageInfo template=new PageInfo("默认",210,297,31.8f,31.8f,25.4f,25.4f,30,95,true);template.fontPath=new String[]{"old-template.gfont"};template.fontChance=new int[]{9};
            Files.write(pageFile,new com.google.gson.Gson().toJson(new PageInfo[]{template}).getBytes("UTF-8"));
            defaults.fontsName=new String[]{"current-default.gfont"};defaults.chance=new int[]{3};
            edt(()->{try{startupPage[0]=(PageInfo)field(new NoteTab(KenjoyDraw.a()),"pageInfo");}catch(Exception e){throw new RuntimeException(e);}});
        }finally{defaults.fontsName=savedFonts;defaults.chance=savedChances;if(savedPages==null)Files.deleteIfExists(pageFile);else Files.write(pageFile,savedPages);}
        check("new note starts with current default fonts instead of stale template fonts",startupPage[0]!=null&&Arrays.equals(startupPage[0].fontPath,new String[]{"current-default.gfont"})&&Arrays.equals(startupPage[0].fontChance,new int[]{3}));
        NoteFonts fonts=new NoteFonts(new java.io.File(System.getProperty("note.fonts")));
        ForbiddenZoneChecks.run(fonts);
        ForbiddenZoneLayoutChecks.run(fonts);
        NoteDocument initial=sample(fonts);NoteDocument draft=initial.copy();long first=draft.atoms.get(0).id,secondSpring=0;
        for(NoteDocument.Atom a:draft.atoms)if(a.text.equals("春"))secondSpring=a.id;
        final long repeated=secondSpring;long unaffected=draft.atoms.get(1).id;
        draft.replace(0,0,"前");check("insert retains existing character identity",draft.atoms.get(1).id==first);
        draft.replace(0,1,"");check("delete restores unaffected identities",draft.atoms.get(0).id==first);
        NoteDocument normalized=new NoteDocument();normalized.replace(0,0,"甲\r\n乙\r丙");check("CRLF normalization retains logical breaks",normalized.text.equals("甲\n乙\n丙"));
        Path oversized=evidence.resolve("oversized.kjnote");try(java.io.RandomAccessFile out=new java.io.RandomAccessFile(oversized.toFile(),"rw")){out.setLength(NoteDocument.MAX_DOCUMENT_BYTES+1);}
        boolean bounded=false;try{NoteDocument.load(oversized);}catch(java.io.IOException expected){bounded=true;}check("oversized article rejected before reading into memory",bounded);Files.delete(oversized);
        NoteDocument compound=new NoteDocument();compound.replace(0,0,"A\u0301😀");check("combining mark and surrogate pair stay whole",compound.atoms.size()==2);
        NoteSelection selection=new NoteSelection();selection.click(first,false);selection.multiple=true;selection.click(repeated,false);check("multi click adds disjoint instances",selection.ids().size()==2);selection.click(first,false);check("multi click toggles membership",selection.ids().size()==1&&selection.ids().contains(repeated));
        NoteLayoutEngine engine=new NoteLayoutEngine(fonts,96);NoteLayout oldLayout=engine.build(initial);String before=geometry(oldLayout);
        check("all drawable source instances appear exactly once",oldLayout.pages.stream().mapToLong(p->p.glyphs.stream().filter(g->!g.whitespace).count()).sum()==initial.atoms.stream().filter(NoteDocument.Atom::drawable).count());
        check("article paginates",oldLayout.pages.size()>1);
        NoteDocument hugePage=initial.copy();hugePage.page.pageWidth=1000000;boolean pixelBound=false;try{NoteTab.image(oldLayout,hugePage,0,96);}catch(IllegalArgumentException expected){pixelBound=true;}check("oversized image export rejected before allocation",pixelBound);
        check("ordinary rebuild preserves geometry",before.equals(geometry(engine.build(initial.copy()))));
        NoteDocument control=initial.copy();control.replace(0,control.text.length(),"春风又绿");control.page.fontPath=new String[]{new java.io.File(control.pool.get(0).relativePath).getName()};control.page.fontChance=null;NoteFonts.Entry baselineFont=fonts.resolve(control.pool.get(0));Class<?> cache=Class.forName("com.kenjoy.kenjoycnc.fonts.x");Field cacheField=cache.getDeclaredField("a");cacheField.setAccessible(true);((Map)cacheField.get(null)).put(control.page.fontPath[0],new java.lang.ref.SoftReference(baselineFont.font()));
        FontsSetData shapeStore=(FontsSetData)Storage.getStore(FontsSetData.class),shapeBackup=new com.google.gson.Gson().fromJson(new com.google.gson.Gson().toJson(shapeStore),FontsSetData.class);FontsSetData neutral=new FontsSetData();for(Field f:FontsSetData.class.getFields())f.set(shapeStore,f.get(neutral));List<com.kenjoy.kenjoycnc.g.e> legacy=new ArrayList<com.kenjoy.kenjoycnc.g.e>();try{com.kenjoy.kenjoycnc.g.a.a(control.text,control.page,legacy,null,0);}finally{for(Field f:FontsSetData.class.getFields())f.set(shapeStore,f.get(shapeBackup));}check("neutral single font geometry matches original layout engine",pathsNear(engine.build(control).pages.get(0).paths,legacy,0.005f));
        edt(()->tab.setDocument(initial));waitDone();check("real NoteTab layout committed",tab.lastFailure()==null&&tab.noteLayout().pages.size()>1);
        AffineTransform machineTransform=tab.machineTransform();List<com.kenjoy.kenjoycnc.g.e> paperPaths=tab.noteLayout().pages.get(0).paths,machinePaths=tab.machinePaths(tab.noteLayout().pages.get(0));
        check("derived affine machine transform matches the application's actual path conversion",affinePathsNear(paperPaths,machinePaths,machineTransform,.002f));
        NoteDocument stable=tab.document();String stableGeometry=geometry(tab.noteLayout());
        NoteFonts.Entry alternate=null,english=null;
        for(NoteFonts.Entry e:fonts.entries()){if(e.file.getName().equals("黄生冈.gfont")&&!e.hash().equals(stable.pool.get(0).hash)&&e.font().a('春'))alternate=e;if(e.folder.startsWith("英文")&&english==null)english=e;}
        if(alternate==null)throw new AssertionError("Need two Chinese fonts");
        final NoteDocument.FontRef target=fonts.ref(alternate);
        edt(()->{tab.selection().click(repeated,false);tab.applyFont(target);});waitDone();
        check("only selected repeated character overridden",tab.document().atom(repeated).override!=null&&tab.document().atom(first).override==null);
        check("unselected automatic font unchanged",tab.document().atom(unaffected).automatic.hash.equals(stable.atom(unaffected).automatic.hash));
        check("selection survives reflow",tab.selection().ids().contains(repeated));
        String edited=geometry(tab.noteLayout());
        edt(()->{try{((JButton)field(tab,"undoButton")).doClick();}catch(Exception e){throw new RuntimeException(e);}});waitDone();
        check("undo restores font and complete geometry",tab.document().atom(repeated).override==null&&stableGeometry.equals(geometry(tab.noteLayout())));
        edt(()->{try{((JButton)field(tab,"redoButton")).doClick();}catch(Exception e){throw new RuntimeException(e);}});waitDone();check("redo restores edited geometry",edited.equals(geometry(tab.noteLayout())));
        if(english!=null){final NoteDocument.FontRef bad=fonts.ref(english);String json=tab.document().encode();edt(()->tab.applyFont(bad));waitDone();check("missing font assignment retains text but blocks output",tab.document().text.equals(NoteDocument.decode(json).text)&&!tab.noteLayout().missing.isEmpty()&&!tab.isOutputReady());}
        edt(()->tab.applyFont(null));waitDone();check("restore default clears explicit binding",tab.document().atom(repeated).override==null);
        final Set<Long> disjoint=new LinkedHashSet<Long>(Arrays.asList(first,repeated));NoteDocument beforeMulti=tab.document();edt(()->{tab.selection().clear();tab.selection().add(disjoint,false);tab.applyFont(target);});waitDone();
        check("disjoint multiple instances receive one font",disjoint.stream().allMatch(id->tab.document().atom(id).override!=null&&tab.document().atom(id).override.hash.equals(target.hash)));
        NoteDocument afterMulti=tab.document();check("disjoint operation preserves every unselected atom",beforeMulti.atoms.stream().filter(a->!disjoint.contains(a.id)).allMatch(a->new com.google.gson.Gson().toJson(a).equals(new com.google.gson.Gson().toJson(afterMulti.atom(a.id)))));
        if(english!=null){final NoteDocument.FontRef bad=fonts.ref(english);String json=tab.document().encode(),geo=geometry(tab.noteLayout());edt(()->tab.applyFont(bad));waitDone();check("multiselect missing font assignment is retained and blocks output",tab.document().text.equals(NoteDocument.decode(json).text)&&!tab.noteLayout().missing.isEmpty()&&!tab.isOutputReady());edt(()->tab.applyFont(target));waitDone();}
        NoteLayout.Page firstPage=tab.noteLayout().pages.get(0);Rectangle2D rectangle=firstPage.glyphs.get(0).cell;check("glyph hit uses character cell",NoteLayout.hit(firstPage,(float)rectangle.getCenterX(),(float)rectangle.getCenterY()).id==first);
        check("frame selection deduplicates source ids",NoteLayout.box(firstPage,rectangle).contains(first));
        final Set<Long> lineIds=new LinkedHashSet<Long>(firstPage.lines.get(0).ids);NoteDocument beforeLine=tab.document();edt(()->{tab.selection().clear();tab.selection().add(lineIds,false);tab.applyFont(target);});waitDone();check("whole line changes captured instances",lineIds.stream().allMatch(id->tab.document().atom(id).override!=null));
        NoteDocument afterLine=tab.document();check("line operation preserves every character outside line",beforeLine.atoms.stream().filter(a->!lineIds.contains(a.id)).allMatch(a->new com.google.gson.Gson().toJson(a).equals(new com.google.gson.Gson().toJson(afterLine.atom(a.id)))));
        check("reflow never changes target membership",tab.selection().capture().equals(lineIds));
        edt(()->{try{tab.selection().multiple=false;tab.selection().clear();clickGlyph(glyph(first),0);clickGlyph(glyph(unaffected),InputEvent.CTRL_DOWN_MASK);}catch(Exception e){throw new RuntimeException(e);}});check("real canvas mouse events select exact disjoint cells",tab.selection().capture().equals(new LinkedHashSet<Long>(Arrays.asList(first,unaffected))));
        edt(()->{try{canvas.a(90f);tab.selection().clear();clickGlyph(glyph(first),0);}catch(Exception e){throw new RuntimeException(e);}});check("rotated preview inverse transform hits original instance",tab.selection().capture().equals(Collections.singleton(first)));edt(()->canvas.a(0f));
        final Set<Long> boxed=new LinkedHashSet<Long>();edt(()->{try{NoteLayout.Glyph g=glyph(first);Point from=screen(g.cell.x-1,g.cell.y+1),to=screen(g.cell.getMaxX()+1,g.cell.getMaxY()-1);Rectangle2D area=new Rectangle2D.Double(g.cell.x-1,g.cell.y+1,g.cell.width+2,g.cell.height-2);boxed.addAll(NoteLayout.box(canvas.layoutPage(),area));canvas.dispatchEvent(new MouseEvent(canvas,MouseEvent.MOUSE_PRESSED,System.currentTimeMillis(),0,from.x,from.y,1,false,MouseEvent.BUTTON1));canvas.dispatchEvent(new MouseEvent(canvas,MouseEvent.MOUSE_DRAGGED,System.currentTimeMillis(),InputEvent.BUTTON1_DOWN_MASK,to.x,to.y,0,false,MouseEvent.NOBUTTON));canvas.dispatchEvent(new MouseEvent(canvas,MouseEvent.MOUSE_RELEASED,System.currentTimeMillis(),0,to.x,to.y,1,false,MouseEvent.BUTTON1));}catch(Exception e){throw new RuntimeException(e);}});check("real canvas frame gesture selects intersected glyph cells",!boxed.isEmpty()&&tab.selection().capture().equals(boxed));
        final Set<Long> visibleLine=new LinkedHashSet<Long>(canvas.layoutPage().lines.get(0).ids);edt(()->{try{NoteLayout.Line line=canvas.layoutPage().lines.get(0);Point p=screen(line.bounds.x-10,line.bounds.getCenterY());canvas.dispatchEvent(new MouseEvent(canvas,MouseEvent.MOUSE_PRESSED,System.currentTimeMillis(),0,p.x,p.y,1,false,MouseEvent.BUTTON1));canvas.dispatchEvent(new MouseEvent(canvas,MouseEvent.MOUSE_RELEASED,System.currentTimeMillis(),0,p.x,p.y,1,false,MouseEvent.BUTTON1));}catch(Exception e){throw new RuntimeException(e);}});check("real canvas gutter gesture selects whole visible line",tab.selection().capture().equals(visibleLine));
        edt(()->{canvas.mouseWheelMoved(new MouseWheelEvent(canvas,MouseEvent.MOUSE_WHEEL,System.currentTimeMillis(),0,100,100,0,false,MouseWheelEvent.WHEEL_UNIT_SCROLL,1,100));});check("extreme wheel zoom keeps invertible preview transform",Math.abs(screen().getDeterminant())>0.0001);edt(()->{canvas.mouseWheelMoved(new MouseWheelEvent(canvas,MouseEvent.MOUSE_WHEEL,System.currentTimeMillis(),0,100,100,0,false,MouseWheelEvent.WHEEL_UNIT_SCROLL,1,-9));});
        Path saved=evidence.resolve("roundtrip.kjnote");edt(()->{try{tab.saveDocument(saved);}catch(Exception e){throw new RuntimeException(e);}});NoteDocument reopened=NoteDocument.load(saved);
        check("save reload retains explicit font identity",reopened.encode().equals(tab.document().encode()));
        check("note mode keeps PDF page control visible",tab.enablePdf());
        final boolean[] rejectedSave={false};edt(()->{javax.swing.Timer cancelSave=new javax.swing.Timer(20,event->{for(Window w:Window.getWindows())if(w instanceof JDialog&&w.isShowing()){JOptionPane pane=saveQuestion((Container)w);if(pane!=null&&pane.getOptions()!=null)pane.setValue(pane.getOptions()[1]);}});try{JFormattedTextField width=(JFormattedTextField)field(tab,"tfWidth");width.setValue(reopened.page.pageWidth+5);cancelSave.start();rejectedSave[0]=!tab.saveDocumentCurrent();}catch(Exception e){throw new RuntimeException(e);}finally{cancelSave.stop();}});
        check("unapplied page change cannot silently save old dimensions",rejectedSave[0]&&tab.hasUnappliedPageSettings()&&NoteDocument.load(saved).page.pageWidth==reopened.page.pageWidth);
        edt(()->{try{((JFormattedTextField)field(tab,"tfWidth")).setValue(reopened.page.pageWidth);}catch(Exception e){throw new RuntimeException(e);}});
        Path corrupt=evidence.resolve("corrupt.kjnote");Files.write(corrupt,"not a note document".getBytes("UTF-8"));final boolean[] corruptAccepted={false},corruptFailed={false};edt(()->corruptAccepted[0]=tab.openDocument(corrupt.toFile(),null,()->corruptFailed[0]=true));waitDone();
        check("corrupt note is rejected before mode transition",corruptAccepted[0]&&corruptFailed[0]&&tab.lastFailure()!=null&&tab.document().encode().equals(reopened.encode()));
        NoteDocument invalidOpen=reopened.copy();invalidOpen.page.pageWidth=15;invalidOpen.page.leftGap=10;invalidOpen.page.rightGap=10;Path invalidFile=evidence.resolve("invalid-layout.kjnote");invalidOpen.save(invalidFile);
        final boolean[] asyncFailure={false},asyncAccepted={false};edt(()->asyncAccepted[0]=tab.openDocument(invalidFile.toFile(),null,()->asyncFailure[0]=true));waitDone();
        check("valid note starts asynchronous layout",asyncAccepted[0]);
        check("asynchronous open failure reports to original mode and preserves article",asyncFailure[0]&&tab.lastFailure()!=null&&tab.document().encode().equals(reopened.encode()));
        check("reload yields same geometry",geometry(engine.build(reopened)).equals(geometry(tab.noteLayout())));
        final boolean[] committed={false};edt(()->committed[0]=tab.onNoteContentSet(new StringBuffer("前"+reopened.text),reopened.format));waitDone();check("legacy article callback waits for successful commit",committed[0]&&tab.document().text.startsWith("前"));long allocated=tab.document().nextId;
        edt(()->{try{((JButton)field(tab,"undoButton")).doClick();}catch(Exception e){throw new RuntimeException(e);}});waitDone();check("undo text edit restores saved clean state without reusing IDs",!tab.isDirty()&&tab.document().text.equals(reopened.text)&&tab.document().nextId>=allocated);
        edt(()->committed[0]=tab.onNoteContentSet(new StringBuffer("😀"+reopened.text),reopened.format));waitDone();check("legacy article callback accepts unsupported character without losing original text",committed[0]&&tab.lastFailure()==null&&tab.document().text.equals("😀"+reopened.text)&&tab.noteLayout().missing.contains("😀"));
        NoteDocument special=reopened.copy();special.replace(0,special.text.length(),"春·•‧∙⋅…—–−\uFEFF\u200B\u00A0A\u0301😀\uE000春\f😀春");
        NoteLayout specialLayout=engine.build(special);
        check("missing glyph does not prevent supported text generation",specialLayout.pages.get(0).paths.size()>=2&&specialLayout.missing.contains("😀")&&specialLayout.missing.contains("A\u0301"));
        check("missing characters remain selectable and are not machine paths",specialLayout.pages.get(0).glyphs.stream().anyMatch(z->z.text.equals("😀")&&z.path.a().length==0)&&specialLayout.pages.get(0).paths.stream().allMatch(z->z.a().length>0));
        check("common punctuation has actual paths",specialLayout.pages.get(0).glyphs.stream().filter(z->"·•‧∙⋅…—–−".contains(z.text)).count()==9&&specialLayout.pages.get(0).glyphs.stream().filter(z->"·•‧∙⋅…—–−".contains(z.text)).allMatch(z->z.path.a().length>0));
        check("invisible copied formatting is not reported as missing",!specialLayout.missing.contains("\uFEFF")&&!specialLayout.missing.contains("\u200B"));
        NoteDocument invisibleOnly=special.copy();invisibleOnly.pool.clear();invisibleOnly.replace(0,invisibleOnly.text.length(),"\uFEFF\u200B");check("format-only article does not require a font",engine.build(invisibleOnly).missing.isEmpty());
        check("warnings identify distinct characters and code points",specialLayout.notice().contains("U+1F600")&&specialLayout.notice().contains("修复"));
        Path specialFile=evidence.resolve("special-characters.kjnote");special.save(specialFile);
        check("special character document roundtrip preserves exact text",NoteDocument.load(specialFile).text.equals(special.text));
        final boolean[] specialOpened={false};edt(()->{tab.setDocument(reopened);});waitDone();edt(()->tab.openDocument(specialFile.toFile(),()->specialOpened[0]=true));waitDone();
        check("special character file loads through real asynchronous open",specialOpened[0]&&tab.lastFailure()==null&&tab.document().text.equals(special.text));
        Path specialText=evidence.resolve("special-characters.txt");Files.write(specialText,special.text.getBytes("UTF-8"));specialOpened[0]=false;edt(()->tab.openDocument(specialText.toFile(),()->specialOpened[0]=true));waitDone();
        check("special character TXT imports without discarding text",specialOpened[0]&&tab.lastFailure()==null&&tab.document().text.equals(special.text));
        JButton cleanup=(JButton)field(tab,"clearMissingButton");check("cleanup button visible only when article has red boxes",cleanup.isVisible()&&cleanup.isEnabled());
        NoteDocument beforeCleanup=tab.document();StringBuilder expectedSpaces=new StringBuilder(),expectedDeleted=new StringBuilder();Set<String> missingText=new HashSet<String>(tab.noteLayout().missing);
        for(NoteDocument.Atom a:beforeCleanup.atoms){if(missingText.contains(a.text))expectedSpaces.append(' ');else{expectedSpaces.append(a.text);expectedDeleted.append(a.text);}}
        edt(()->tab.clearMissingCharacters(true));waitDone();
        check("replace red boxes with spaces across all pages and hide button",tab.lastFailure()==null&&tab.document().text.equals(expectedSpaces.toString())&&tab.noteLayout().missing.isEmpty()&&!cleanup.isVisible());
        check("cleanup preserves unaffected glyph identity and font sampling",beforeCleanup.atoms.stream().filter(a->!missingText.contains(a.text)).allMatch(a->{NoteDocument.Atom after=tab.document().atom(a.id);return after!=null&&new com.google.gson.Gson().toJson(a).equals(new com.google.gson.Gson().toJson(after));}));
        edt(()->{try{((JButton)field(tab,"undoButton")).doClick();}catch(Exception e){throw new RuntimeException(e);}});waitDone();
        check("undo restores exact red box text and cleanup button",tab.document().text.equals(beforeCleanup.text)&&cleanup.isVisible());
        edt(()->tab.clearMissingCharacters(false));waitDone();
        check("delete removes only red boxes across all pages",tab.lastFailure()==null&&tab.document().text.equals(expectedDeleted.toString())&&tab.noteLayout().missing.isEmpty()&&!cleanup.isVisible());
        edt(()->{try{((JButton)field(tab,"undoButton")).doClick();((JButton)field(tab,"redoButton")).doClick();}catch(Exception e){throw new RuntimeException(e);}});waitDone();
        edt(()->{try{((JButton)field(tab,"redoButton")).doClick();}catch(Exception e){throw new RuntimeException(e);}});waitDone();
        check("redo reapplies red box deletion",tab.document().text.equals(expectedDeleted.toString())&&!cleanup.isVisible());
        edt(()->tab.setDocument(reopened));waitDone();
        check("normal article keeps cleanup button hidden",!cleanup.isVisible());
        int pageIndex=tab.getCurrentPageIndex();BufferedImage image=tab.renderToImage(1);check("image export leaves current page unchanged",tab.getCurrentPageIndex()==pageIndex);
        BufferedImage expected=NoteTab.image(tab.noteLayout(),tab.document(),1,96);check("selection overlay excluded from exported image",Arrays.equals(image.getRGB(0,0,image.getWidth(),image.getHeight(),null,0,image.getWidth()),expected.getRGB(0,0,expected.getWidth(),expected.getHeight(),null,0,expected.getWidth())));
        String beforeExport=tab.document().encode();NoteExportHooks.begin(2);String exportBefore=geometry(tab.exportLayout());NoteExportHooks.Job snapshot=NoteExportHooks.current(tab);List<List<com.kenjoy.kenjoycnc.g.e>> captured=(List<List<com.kenjoy.kenjoycnc.g.e>>)field(snapshot,"paths");check("frozen affine paths match original machine transform",pathsNear(captured.get(0),tab.machinePaths(tab.noteLayout().pages.get(0)),0.002f));int originalDpi=com.kenjoy.kenjoycnc.model.Settings.getInst().dpi;com.kenjoy.kenjoycnc.model.Settings.getInst().dpi=192;try{check("batch image dimensions use captured DPI",tab.renderToImage(0).getWidth()==Math.round(tab.document().page.pageWidth*originalDpi/25.4f));NoteExportHooks.afterCopy(tab);}finally{com.kenjoy.kenjoycnc.model.Settings.getInst().dpi=originalDpi;}check("nonrandom batch reuses same snapshot",geometry(tab.exportLayout()).equals(exportBefore));check("export freeze does not replace live document",tab.document().encode().equals(beforeExport));NoteExportHooks.end();
        List generators=tab.getExportGcodeGenerator();check("all pages have Gcode generators",generators.size()==tab.getPageNum());
        final boolean[] machineReady={false};final com.kenjoy.kenjoycnc.c.a[] machineSnapshot={null};final String[] machineSource={null};
        edt(()->{try{((JFormattedTextField)field(tab,"tfCurPage")).setValue(1);((JFormattedTextField)field(tab,"tfCurPage")).postActionEvent();machineReady[0]=tab.beginMachineJob();machineSnapshot[0]=tab.getGcodeGenerator();machineSource[0]=tab.machineJobSource();((JButton)field(tab,"btnNextPage")).doClick();}catch(Exception e){throw new RuntimeException(e);}});
        check("machine job freezes note page across navigation",machineReady[0]&&tab.getGcodeGenerator()==machineSnapshot[0]&&"笔记当前页 1/".concat(String.valueOf(tab.getPageNum())).equals(machineSource[0]));
        edt(()->tab.endMachineJob());check("machine job source clears after finish",tab.machineJobSource()==null);
        com.kenjoy.kenjoycnc.c.a generator=(com.kenjoy.kenjoycnc.c.a)generators.get(0);generator.a();check("real Gcode generated without hardware",generator.g().contains("G")&&generator.g().length()>100);
        String live=tab.document().encode();Object batch=exporter("fixed",2,false);((Runnable)batch).run();edt(()->{});boolean same=true;for(int page=1;page<=tab.getPageNum();page++){Path one=evidence.resolve("batch/fixed1/fixed"+page+".gcode"),two=evidence.resolve("batch/fixed2/fixed"+page+".gcode");same&=Files.exists(one)&&Files.exists(two)&&Arrays.equals(Files.readAllBytes(one),Files.readAllBytes(two));}check("real batch exporter writes two identical complete page sets",same&&!((Boolean)field(batch,"y"))&&live.equals(tab.document().encode()));edt(()->((JDialog)batch).dispose());
        Object images=exporter("images",2,true);((Runnable)images).run();edt(()->{});boolean imageFiles=true;for(int page=1;page<=tab.getPageNum();page++){Path one=evidence.resolve("batch/images1/images"+page+".jpg"),two=evidence.resolve("batch/images2/images"+page+".jpg");BufferedImage read=ImageIO.read(one.toFile());imageFiles&=read!=null&&read.getWidth()==Math.round(tab.document().page.pageWidth*96/25.4f)&&Arrays.equals(Files.readAllBytes(one),Files.readAllBytes(two));}check("real batch image exporter writes readable matching copies",imageFiles);edt(()->((JDialog)images).dispose());
        ImageIO.write(tab.renderToImage(0),"png",evidence.resolve("article-output.png").toFile());
        final NoteDocument current=tab.document();NoteDocument broken=current.copy();broken.page.pageWidth=15;broken.page.leftGap=10;broken.page.rightGap=10;edt(()->tab.setDocument(broken));waitDone();check("invalid layout preserves previous article",tab.lastFailure()!=null&&tab.document().encode().equals(current.encode()));
        NoteDocument random=current.copy();random.shapes.randomRotate=new float[]{-3,3};random.shapes.randomFontSize=new float[]{0.95f,1.05f};random.rerandomize();NoteLayout r1=engine.build(random);String randomGeometry=geometry(r1);check("random factors persist across rebuild",randomGeometry.equals(geometry(engine.build(random.copy()))));
        Set<Long> locked=new HashSet<Long>();for(NoteDocument.Atom a:random.atoms)if(a.override!=null)locked.add(a.id);Map<Long,String> lockedFonts=new HashMap<Long,String>();for(long id:locked)lockedFonts.put(id,random.atom(id).override.hash);random.rerandomize();engine.build(random);check("rerandomize preserves manual font bindings",locked.stream().allMatch(id->lockedFonts.get(id).equals(random.atom(id).override.hash)));
        edt(()->tab.setDocument(random));waitDone();NoteDocument beforeUpdate=tab.document();String updateGeometry=geometry(tab.noteLayout());Map<Long,String> manualAtoms=new HashMap<Long,String>();for(NoteDocument.Atom atom:beforeUpdate.atoms)if(atom.override!=null)manualAtoms.put(atom.id,new com.google.gson.Gson().toJson(atom));long[] navigationAnchor={-1};boolean[] navigatedWhileBusy={false};FontsSetData updateSettings=(FontsSetData)Storage.getStore(FontsSetData.class);float[] savedSize=updateSettings.randomFontSize,savedRotate=updateSettings.randomRotate;updateSettings.randomFontSize=new float[]{.95f,1.05f};updateSettings.randomRotate=new float[]{-3,3};
        try{edt(()->{try{int pageBefore=tab.getCurrentPageIndex();((JButton)field(KenjoyDraw.a(),"i")).doClick();if(tab.noteLayout().pages.size()>1){((JButton)field(tab,"btnNextPage")).doClick();navigatedWhileBusy[0]=tab.isBusy()&&tab.getCurrentPageIndex()==pageBefore+1;navigationAnchor[0]=tab.noteLayout().pages.get(tab.getCurrentPageIndex()).glyphs.get(0).id;}}catch(Exception e){throw new RuntimeException(e);}});waitDone();}finally{updateSettings.randomFontSize=savedSize;updateSettings.randomRotate=savedRotate;}
        NoteDocument afterUpdate=tab.document();check("main Update rerandomizes automatic glyphs",tab.lastFailure()==null&&afterUpdate.generation==beforeUpdate.generation+1);
        check("main Update preserves all manually bound atom states",manualAtoms.entrySet().stream().allMatch(e->e.getValue().equals(new com.google.gson.Gson().toJson(afterUpdate.atom(e.getKey())))));
        check("pending navigation anchors the page visible at commit",navigatedWhileBusy[0]&&navigationAnchor[0]>=0&&tab.getCurrentPageIndex()==tab.noteLayout().pageOf(navigationAnchor[0]));
        edt(()->{try{((JButton)field(tab,"undoButton")).doClick();}catch(Exception e){throw new RuntimeException(e);}});waitDone();check("Update is one undoable transaction",tab.document().encode().equals(beforeUpdate.encode())&&geometry(tab.noteLayout()).equals(updateGeometry));
        NoteDocument beforeLayout=tab.document();String beforeLayoutGeometry=geometry(tab.noteLayout());edt(()->tab.applyLayoutAsync());waitDone();check("Apply Layout preserves chosen glyphs and generation",tab.lastFailure()==null&&tab.document().generation==beforeLayout.generation&&beforeLayoutGeometry.equals(geometry(tab.noteLayout())));
        NoteDocument beforeRandom=tab.document();edt(()->tab.rerandomizeAsync());waitDone();check("explicit rerandomize advances generation",tab.lastFailure()==null&&tab.document().generation==beforeRandom.generation+1);
        edt(()->{try{((JButton)field(tab,"undoButton")).doClick();}catch(Exception e){throw new RuntimeException(e);}});waitDone();check("explicit rerandomize is undoable",tab.document().encode().equals(beforeRandom.encode()));
        final float oldWidth=tab.document().page.pageWidth;edt(()->{try{((JFormattedTextField)field(tab,"tfWidth")).setValue(oldWidth+20);((JButton)field(KenjoyDraw.a(),"i")).doClick();}catch(Exception e){throw new RuntimeException(e);}});waitDone();check("Update reads current page fields",tab.lastFailure()==null&&tab.document().page.pageWidth==oldWidth+20);
        edt(()->{try{((JButton)field(tab,"undoButton")).doClick();}catch(Exception e){throw new RuntimeException(e);}});waitDone();check("page undo synchronizes fields with restored preview",tab.document().page.pageWidth==oldWidth&&((Number)((JFormattedTextField)field(tab,"tfWidth")).getValue()).floatValue()==oldWidth);
        check("loaded template name agrees with document page",String.valueOf(((JComboBox)field(tab,"cbSettings")).getSelectedItem()).equals(tab.document().page.name));
        String beforeBadUpdate=tab.document().encode(),beforeBadGeometry=geometry(tab.noteLayout());edt(()->{try{((JFormattedTextField)field(tab,"tfWidth")).setValue(1);((JButton)field(KenjoyDraw.a(),"i")).doClick();}catch(Exception e){throw new RuntimeException(e);}});waitDone();check("failed Update preserves random state and geometry",tab.lastFailure()!=null&&beforeBadUpdate.equals(tab.document().encode())&&beforeBadGeometry.equals(geometry(tab.noteLayout())));edt(()->tab.setDocument(current));waitDone();
        NoteDocument overrideOnly=current.copy();for(NoteDocument.Atom a:overrideOnly.atoms)if(a.drawable())a.override=target;overrideOnly.pool=Collections.singletonList(new NoteDocument.FontRef("missing.gfont",String.join("",Collections.nCopies(64,"0")),"missing"));check("explicit bindings remain usable without obsolete default font",!engine.build(overrideOnly).pages.isEmpty());
        NoteDocument chances=current.copy();chances.pool.add(target);chances.chances=new int[]{1};chances.rerandomize();check("short legacy chance array does not crash",!engine.build(chances).pages.isEmpty());
        Path bom=evidence.resolve("bom.txt");Files.write(bom,"\uFEFF春风\r\n明月".getBytes("UTF-8"));Method readText=NoteTab.class.getDeclaredMethod("readText",java.io.File.class,String.class);readText.setAccessible(true);check("UTF8 BOM import keeps clean logical text",readText.invoke(tab,bom.toFile(),"UTF-8").equals("春风\n明月"));
        Path mutation=evidence.resolve("font-mutation");Files.createDirectories(mutation);Path fontCopy=mutation.resolve("sample.gfont");Files.copy(alternate.file.toPath(),fontCopy,StandardCopyOption.REPLACE_EXISTING);NoteFonts isolated=new NoteFonts(mutation.toFile());NoteFonts.Entry entry=isolated.entries().get(0);String originalHash=entry.hash();entry.font();Files.write(fontCopy,new byte[]{0},StandardOpenOption.APPEND);boolean rejected=false;try{entry.font();}catch(java.io.IOException expectedFailure){rejected=true;}check("changed font file cannot silently reuse cached identity",rejected);isolated.close();
        NoteDocument abort=current.copy();abort.shapes.randomFontSize=new float[]{1000,1000};edt(()->{tab.setDocument(abort);try{((JCheckBox)field(tab,"randomCopies")).setSelected(true);}catch(Exception e){throw new RuntimeException(e);}});waitDone();Object badBatch=exporter("preflight-abort",2,false);boolean preflightRejected=false;try{((Runnable)badBatch).run();}catch(IllegalStateException expectedFailure){preflightRejected="无法冻结或预检文章导出结果".equals(expectedFailure.getMessage())&&expectedFailure.getCause()!=null&&expectedFailure.getCause().getMessage()!=null;}edt(()->{});boolean noPreflightOutput=!Files.exists(evidence.resolve("batch/preflight-abort1"))&&!Files.exists(evidence.resolve("batch/preflight-abort2"));boolean errorShown=((JLabel)field(badBatch,"l")).getText().startsWith("导出失败");check("random layout preflight failure stops before output and clears exporter state",preflightRejected&&!((Boolean)field(badBatch,"y"))&&NoteExportHooks.current(tab)==null&&noPreflightOutput&&errorShown);edt(()->{((JDialog)badBatch).dispose();try{((JCheckBox)field(tab,"randomCopies")).setSelected(false);}catch(Exception e){throw new RuntimeException(e);}tab.setDocument(current);});waitDone();
        edt(()->{try{tab.selection().clear();tab.selection().multiple=false;clickGlyph(glyph(first),0);clickGlyph(glyph(repeated),InputEvent.CTRL_DOWN_MASK);}catch(Exception e){throw new RuntimeException(e);}});
        edt(()->{BufferedImage shot=new BufferedImage(canvas.getWidth(),canvas.getHeight(),BufferedImage.TYPE_INT_RGB);Graphics2D out=shot.createGraphics();out.setBackground(Color.WHITE);canvas.paint(out);out.dispose();try{ImageIO.write(shot,"png",evidence.resolve("preview-component.png").toFile());}catch(Exception e){throw new RuntimeException(e);}});
        SidebarChecks.run(evidence);
        runResumeChecks(tab);
        edt(()->tab.setFile(bom.toFile()));waitDone();check("open article accepts TXT and marks it for native save",tab.lastFailure()==null&&tab.document().text.equals("春风\n明月")&&tab.isDirty()&&field(tab,"documentFile")==null);
        Path importedSave=evidence.resolve("imported-txt.kjnote");edt(()->{try{tab.saveDocument(importedSave);}catch(Exception e){throw new RuntimeException(e);}});check("imported TXT saves as KJNOTE",NoteDocument.load(importedSave).text.equals("春风\n明月")&&!tab.isDirty());
        edt(()->tab.onNoteContentSet(new StringBuffer("春风\n明月再见"),tab.document().format));waitDone();check("article edit marks existing file dirty",tab.isDirty());
        final boolean[] savedCurrent={false};edt(()->savedCurrent[0]=tab.saveDocumentCurrent());
        check("article Save updates existing KJNOTE and clean state",savedCurrent[0]&&!tab.isDirty()&&NoteDocument.load(importedSave).text.equals("春风\n明月再见")&&importedSave.equals(field(tab,"documentFile")));
        Path word=evidence.resolve("imported.docx");try(org.apache.poi.xwpf.usermodel.XWPFDocument doc=new org.apache.poi.xwpf.usermodel.XWPFDocument();java.io.OutputStream stream=Files.newOutputStream(word)){doc.createParagraph().createRun().setText("春风明月");doc.write(stream);}
        edt(()->tab.setFile(word.toFile()));waitDone();check("open article accepts DOCX as unsaved article",tab.lastFailure()==null&&tab.document().text.contains("春风明月")&&tab.isDirty()&&field(tab,"documentFile")==null);
        final Window[] modalResolved={null,null};final boolean[] modalShowing={false};
        edt(()->{try{
            final JFrame ownerFrame=KenjoyDraw.a().f();
            final Method resolve=NoteFileDialogs.class.getDeclaredMethod("effectiveOwner",Component.class);resolve.setAccessible(true);
            check("enabled frame stays its own native dialog owner",resolve.invoke(null,ownerFrame)==ownerFrame);
            final JDialog modal=new JDialog(ownerFrame,"OwnerCheckModal",true);modal.setSize(120,80);modal.setLocationRelativeTo(ownerFrame);
            javax.swing.Timer checkTimer=new javax.swing.Timer(40,ev->{try{modalShowing[0]=modal.isShowing();modalResolved[0]=(Window)resolve.invoke(null,ownerFrame);modalResolved[1]=(Window)resolve.invoke(null,modal);}catch(Exception ex){throw new RuntimeException(ex);}finally{modal.dispose();}});
            checkTimer.setRepeats(false);checkTimer.start();modal.setVisible(true);
            check("modal-blocked frame resolves effective native dialog owner to active modal dialog",modalShowing[0]&&modalResolved[0]==modal&&modalResolved[1]==modal);
        }catch(Exception e){throw new RuntimeException(e);}});
        Files.write(evidence.resolve("COMPLETE.txt"),("PASS "+results.size()+" assertions; Java "+System.getProperty("java.version")+" UI, fonts, layout, document, image and Gcode. No hardware.\n").getBytes("UTF-8"));System.out.println("NOTE_CHECKS_COMPLETE "+results.size());
    }
    private static void runResumeChecks(NoteTab tab)throws Exception{
        edt(()->tab.activatePreviewPage(0));
        NoteWriteProgress.clear();
        check("fresh page has no resume progress",!tab.hasResumeProgress()&&tab.currentPageSource().equals("笔记当前页 1/"+tab.getPageNum()));
        final String[] fullHolder={null},baselineHolder={null};
        final boolean[] isPageGen={false};
        final NoteWriteProgress.Snapshot[] snapHolder={null};
        edt(()->{
            if(!tab.beginMachineJob())throw new AssertionError("beginMachineJob failed");
            com.kenjoy.kenjoycnc.c.a gen=tab.getGcodeGenerator();
            gen.a();fullHolder[0]=gen.g();
            isPageGen[0]=gen instanceof NoteWriteProgress.PageGenerator;
            snapHolder[0]=((NoteWriteProgress.PageGenerator)gen).snapshot();
            com.kenjoy.kenjoycnc.c.a baseline=new com.kenjoy.kenjoycnc.c.c(com.kenjoy.kenjoycnc.L.b(tab.machinePaths(tab.noteLayout().pages.get(0))),com.kenjoy.kenjoycnc.model.Settings.getInst().nearDst,false);
            baseline.a();baselineHolder[0]=baseline.g();
            tab.endMachineJob();
        });
        check("note machine job uses per-glyph PageGenerator",isPageGen[0]);
        check("PageGenerator output matches baseline G-code byte-for-byte",fullHolder[0].equals(baselineHolder[0]));
        NoteWriteProgress.Snapshot snap=snapHolder[0];
        check("every writable path has an ordered command interval",snap.glyphs.size()==tab.noteLayout().pages.get(0).paths.size()&&snap.glyphs.size()>=5&&snap.glyphs.get(0).startCmd>0&&snap.glyphs.get(1).endCmd<snap.glyphs.get(2).startCmd&&snap.totalCommands>=snap.glyphs.get(snap.glyphs.size()-1).endCmd);
        snap.updateCommandCounts(snap.totalCommands,snap.glyphs.get(1).endCmd,snap.glyphs.get(2).startCmd);
        snap.status="INTERRUPTED";snap.reason="USB 连接已断开";snap.resumeGlyphId=snap.recommendedResumeGlyphId();
        edt(()->tab.onWriteJobInterrupted(snap));
        check("interruption highlights confirmed and in-flight glyphs and recommends resume glyph",
            tab.hasResumeProgress()&&tab.resumeGlyphIdForPage(0)==snap.glyphs.get(2).id
            &&tab.currentPageSource().contains("续写")&&tab.currentPageSource().contains(snap.glyphs.get(2).text));
        edt(()->{try{((JButton)field(tab,"resumeNextButton")).doClick();}catch(Exception e){throw new RuntimeException(e);}});
        check("next-glyph button advances resume target",tab.resumeGlyphIdForPage(0)==snap.glyphs.get(3).id);
        edt(()->{try{((JButton)field(tab,"resumeInterruptedButton")).doClick();}catch(Exception e){throw new RuntimeException(e);}});
        check("interrupted-glyph button restores interrupted target",tab.resumeGlyphIdForPage(0)==snap.glyphs.get(2).id);
        final long fifthId=snap.glyphs.get(4).id;
        edt(()->{try{tab.selection().click(fifthId,false);tab.selectionChanged();((JButton)field(tab,"resumeFromSelectionButton")).doClick();}catch(Exception e){throw new RuntimeException(e);}});
        check("set-resume button adopts selected writable glyph",tab.resumeGlyphIdForPage(0)==fifthId);
        final String[] resumedGcode={null},fullExportGcode={null};
        final NoteWriteProgress.Snapshot[] resumedSnap={null};
        edt(()->{
            if(!tab.beginMachineJob())throw new AssertionError("resumed beginMachineJob failed");
            com.kenjoy.kenjoycnc.c.a resumed=tab.getGcodeGenerator();
            resumed.a();resumedGcode[0]=resumed.g();
            resumedSnap[0]=((NoteWriteProgress.PageGenerator)resumed).snapshot();
            List exports=tab.getExportGcodeGenerator();
            com.kenjoy.kenjoycnc.c.a fullExport=(com.kenjoy.kenjoycnc.c.a)exports.get(0);
            fullExport.a();fullExportGcode[0]=fullExport.g();
            tab.endMachineJob();
        });
        check("resumed G-code slices strictly from chosen glyph onward",resumedSnap[0].startGlyphOrder==4&&resumedSnap[0].totalCommands<snap.totalCommands&&resumedGcode[0].length()<fullHolder[0].length());
        check("full-page export stays complete despite resume marker",fullExportGcode[0].equals(fullHolder[0]));
        edt(()->{try{((JButton)field(tab,"clearResumeButton")).doClick();}catch(Exception e){throw new RuntimeException(e);}});
        check("clear resume restores default whole-page source",!tab.hasResumeProgress()&&tab.resumeGlyphIdForPage(0)==-1L&&tab.currentPageSource().equals("笔记当前页 1/"+tab.getPageNum()));
        NoteWriteProgress.clear();
    }
}
